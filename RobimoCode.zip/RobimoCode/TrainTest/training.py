import os
import sys

sys.path.insert(0, '/home/lorraineshunie/RobimoCode/Utils/')
sys.path.insert(1, '/home/lorraineshunie/RobimoCode/Preprocessing')
sys.path.insert(2, '/home/lorraineshunie/RobimoCode/Model_GNN')
from Preprocessing import custom_dataset as cd
from Model_GNN import model as md
import numpy as np
import tensorflow as tf
from Preprocessing import input_data as Inp
from Preprocessing import custom_dataset as cd
from Utils import utils as ud
from numpy import linalg as LA
import matplotlib.pyplot as plt

np.random.seed(19680801)
physical_devices = tf.config.list_physical_devices("GPU")
if len(physical_devices) > 0:
    tf.config.experimental.set_memory_growth(physical_devices[0], True)


# dir_path = "/home/ls/RobimoCode/MyDataset"
# count = 0
# for path in os.listdir(dir_path):
#    if os.path.isfile(path):
#################################
# ************Train *************#
#################################
@tf.function
def train():
    def train():
        with tf.GradientTape() as tape:
            predictions, _, _ = md.model([cd.X, cd.A], training=True)
            # predictions = tf.cast(tf.reshape(predictions, [1, 16]), tf.float64)
            print('predictions:', predictions)
            loss = tf.reduce_mean(
                tf.nn.weighted_cross_entropy_with_logits(logits=predictions, labels=cd.A_label,
                                                         pos_weight=cd.pos_weight))
            loss += sum(md.model.losses)
        gradients = tape.gradient(loss, md.model.trainable_variables)
        md.opt.apply_gradients(zip(gradients, md.model.trainable_variables))
        return loss

    # Training
    best_val_roc = 0
    for epoch in range(1, md.epochs):
        loss = train()
        print(f"epoch: {epoch:d} -- loss: {loss:.3f}")
        # Check performance on Validation
    if md.epochs % md.val_epochs == 0:
        _, adj_rec, _ = md.model([cd.X, cd.A])
        adj_rec = adj_rec.numpy()
        # best_val_roc = val_roc
        acc = np.mean(np.round(adj_rec) == cd.graph.a.toarray())
        print(f"Val AUC: {best_val_roc * 100:.1f}, Accuracy: {acc * 100:.1f}")


# Testing
_, adj_rec, node_emb = md.model([cd.X, cd.A])
adj_rec = np.round(adj_rec.numpy(), 3)
print(f"adje_new:{adj_rec}")
Inp.show_data(cd.X, cd.A, adj_rec)

label_gpt, label_offgpt = [], []


def Pseudo_labeling(adj_matrix_recon):
    value, vectors = LA.eig(adj_matrix_recon)
    print(f"Vector :{vectors}, Value vector : {value}")
    # Sorted Eigenvalue and eigenvectors
    idx = np.argsort(value)
    value = value[idx]
    # print('value:', value)
    for id, v_id in enumerate(value):
        val = value[id]
        print(val)
        u = vectors[:, id].tolist()
        if v_id > 0:
            label_gpt.append(u)
        else:
            label_offgpt.append(u)
    print('GP:', label_gpt)
    print('OffGP:', label_offgpt)
    return label_gpt, label_offgpt


ytrue, y2 = Pseudo_labeling(np.round(adj_rec, 3))
#plt.scatter(ytrue, y=ytrue, marker='o',  color='hotpink')
Inp.recon_data(ytrue)
#plt.plot()
#plt.savefig('ytrue_1.png')
#plt.show()

# Build classifier
# dbscan clustering
from numpy import unique
from numpy import where
from sklearn.cluster import DBSCAN
from matplotlib import pyplot


# define the model
model = DBSCAN(eps=0.30, min_samples=9)
# fit model and predict clusters
ypred = model.fit_predict(adj_rec)
print('predict:', ypred)
# retrieve unique clusters
clusters = unique(ypred)
# create scatter plot for samples from each cluster
for cluster in clusters:
    # get row indexes for samples with this cluster
    row_ix = where(ypred == cluster)
    # create scatter of these samples
    pyplot.scatter(adj_rec[row_ix, 0], adj_rec[row_ix, 1], color='#88c999')
# show the plot
pyplot.savefig('classifer.png')
plt.tight_layout()
pyplot.show()

