import numpy as np
from sklearn.decomposition import PCA

"""
Singular Value Decompositio(SVD) to get feature nodes of original data
"""


def Pca(inp_data, num_componnets=3):
    X_meaned = inp_data - np.mean(inp_data, axis=0)
    cov_mat = np.cov(X_meaned, rowvar=False)
    eigen_values, eigen_vectors = np.linalg.eigh(cov_mat)
    sorted_index = np.argsort(eigen_values)[:: 1]  # zyz
    sorted_eigenvalue = eigen_values[sorted_index]
    sorted_eigenvectors = eigen_vectors[:, sorted_index]
    n_components = num_componnets  # you can select any number of components.
    eigenvector_subset = sorted_eigenvectors[:, 0:n_components]
    pca_data = np.dot(eigenvector_subset.transpose(), X_meaned.transpose()).transpose()
    return pca_data

# def Pca(inp_data, num_componnets=0.8):
#    pca_transformer = PCA(num_componnets)
#    pca_data = pca_transformer.fit_transform(inp_data)
#    return pca_data
