"""
The purpose of this code is to create a custom dataset for GCN
"""
import spektral
import tensorflow as tf
import numpy as np
import pandas as pd
from numpy import linalg as LA
from pyntcloud import PyntCloud
from sklearn.preprocessing import MinMaxScaler
import seaborn as sns
import matplotlib.pyplot as plt
import scipy.sparse as sp
import Preprocessing.Pca as pc

physical_devices = tf.config.list_physical_devices("GPU")
if len(physical_devices) > 0:
    tf.config.experimental.set_memory_growth(physical_devices[0], True)


# ******************************** Read customer raw data *************************************#
class Preprocess:
    def __init__(self, path, num_row, knn, **kwargs):
        self.path = path
        self.num_row = num_row
        self.knn = knn
        super(Preprocess, self).__init__(**kwargs)

    def read_file(self):
        with open(self.path, "r") as file:
            data = pd.read_csv(file, delimiter=',')
            # dataXYZ = data.iloc[:, 0:3]
            # n_data = len(dataXYZ)
            clmns = ['x', 'y', 'z']
            data = {'x': data.iloc[:, 0],
                    'y': data.iloc[:, 1],
                    'z': data.iloc[:, 2],
                    # 'colors': np.random.rand(255)  # not belong on the original  raw data
                    }
            pointXYZ = PyntCloud(pd.DataFrame(data, columns=clmns))
        return pointXYZ

    # Normalized raw data [0, 1]
    def Normalize_data(self):
        data = self.read_file()
        data = np.array(data.xyz)
        data = sp.coo_matrix(data).toarray()
        scaler = MinMaxScaler()
        normalized = scaler.fit_transform(data)
        return normalized

    # Get neighbor for each node
    def get_neighbor(self):
        d = self.read_file()
        kdtree_id = d.add_structure("kdtree")
        k_neighbors = d.get_neighbors(k=self.knn, kdtree=kdtree_id)
        return k_neighbors

    # Computation  Gaussian kernel
    def getgaussiankernel(self, draw1, draw2, sigma):
        tm_arr = np.array((draw1, draw2))
        norm = np.round(LA.norm(tm_arr, axis=0), 3)
        gaussian_kernel = np.exp(-(np.divide(np.power(norm, 2), np.power(sigma, 2))))
        return gaussian_kernel

    # Computation weight between two nodes using Gaussian kernel
    def weight(self, idx_row=1):
        # here use len neighbor array
        list_arr = []
        list_GK = []
        data_raw = np.array(self.Normalize_data())
        data_neighbor = self.get_neighbor()
        neighbor = data_neighbor
        Lis_weig = [0 for i in range(idx_row)]
        # We used  each row that contained 3 neighborhood nodes
        for i in range(0, self.num_row, idx_row):  # use length array neighbor
            neighbor_array = neighbor[i]
            for j in neighbor_array:
                list_arr.append(data_raw[j])
            my_list_arr = np.array(list_arr)
            cpt = i
            kk = len(my_list_arr)
            list_GK.append(self.getgaussiankernel(my_list_arr[cpt], my_list_arr[cpt + 1 - kk], sigma=1))
            Lis_weig = np.array(np.round(list_GK, 3))
            i += 1
        return Lis_weig


# ******************************** End reading customer raw data *****************************************#
# ******************************** Build customer graph **************************************************#

class buildGraph:
    def __init__(self, numvertex, **kwargs):
        self.adjMatrix = [[-1] * numvertex for x in range(numvertex)]
        self.numvertex = numvertex
        self.vertices = {}
        self.verticeslist = [0] * numvertex
        super(buildGraph, self).__init__(**kwargs)

    def set_vertex(self, vtx, id):
        if 0 <= vtx <= self.numvertex:
            self.vertices[id] = vtx
            self.verticeslist[vtx] = id

    def set_edge(self, frm, to, cost=0):
        frm = self.vertices[frm]
        to = self.vertices[to]
        self.adjMatrix[frm][to] = cost
        # for directed graph do not add this
        self.adjMatrix[to][frm] = cost

    def get_vertex(self):
        return self.verticeslist

    def get_edges(self):
        edges = []
        for i in range(self.numvertex):
            for j in range(self.numvertex):
                if self.adjMatrix[i][j] != -1:  # modify contain adjacency matrix
                    edges.append((self.verticeslist[i], self.verticeslist[j], self.adjMatrix[i][j]))
        return edges

    def get_matrix(self):
        return self.adjMatrix


# ********************************  End customer graph **************************************************#

# ******************************** created feature none, adjacency matrix , and label********************#

class Preprocess_2:
    def __init__(self, path, num_row, knn, **kwargs):
        self.path = path
        self.num_row = num_row
        self.knn = knn
        super(Preprocess_2, self).__init__(**kwargs)

    def adj_matrix(self):  # A is weight matrix A=n*n
        preprocess = Preprocess(path=self.path, num_row=self.num_row, knn=self.knn)
        weig = preprocess.weight()  # selected num of row weight
        num_weig = len(weig)
        neig = preprocess.get_neighbor()
        neig_idx = np.array(neig[:num_weig])
        num_neig = len(neig_idx)
        Madj = [[0 for i in range(self.knn)] for j in range(self.knn)]
        Madjlist = [[0 for i in range(self.knn)] for j in range(self.knn)]
        Medgelist = [[0 for i in range(self.knn)] for j in range(self.knn)]
        i, k = 0, 0
        for idxx in range(0, num_neig, 1):
            n_node = len(neig_idx[i])  # num of node per row
            G = buildGraph(n_node)
            nei_idxx = neig_idx[i]
            w = weig[i]
            for id_, val in enumerate(nei_idxx):
                G.set_vertex(vtx=id_, id=val)
            for n in range(n_node - 1):
                for _ in w:
                    G.set_edge(frm=nei_idxx[n], to=nei_idxx[n + 1], cost=w[k])
                    k += 1
                    break
            Madjlist = np.asarray(G.get_vertex())
            Medgelist = np.asarray(G.get_edges())
            Madj = np.asarray(G.get_matrix())
            # print("Medge:", Medgelist)
            i += 1
            k = 0
        return Madj, Madjlist, Medgelist

    #def matrix_feature(self):  # X=Feature vector, or nodes X = n*f
    #    global feat_data
    #    preprocess = Preprocess(path=self.path, num_row=self.num_row, knn=self.knn)
    #    Data = preprocess.Normalize_data()
    #    Data = pc.Pca(Data)
    #    Feature_matrix = [[0 for i in range(3)] for j in range(3)]
    #    for i in range(0, self.num_row, 3):
    #        data = np.round(Data[i:self.knn + i], 3)
    #        lda = len(data)
    #        feat_data = [[0 for i in range(lda)] for j in range(lda)]
    #        # print("i:{} feature data:{}".format(i, feat_data))
    #        for j in range(len(data)-1):
    #            data_idx = data[j]
    #            for k in range(len(data_idx)):
    #                dix = data_idx[k]
    #               feat_data[j][k] = dix
    #        Feature_matrix = np.asarray(feat_data)
    #        print("i:{} feature data:{}".format(i, Feature_matrix))
    #    return Feature_matrix

    def matrix_feature(self):  # D
        global feat_data
        adj, adjlis, edgelist = self.adj_matrix()
        # Feature_matrix = [[0 for i in range(self.knn)] for j in range(self.knn)]
        Feature_matrix = [[0 for i in range(3)] for j in range(3)]
        Feature_matrix = spektral.utils.degree_matrix(adj)
        return Feature_matrix

    def y_label(self):
        matrix_adj, matrix_adj_list, matrix_edge = self.adj_matrix()
        # matrix_feat = self.matrix_feature()
        y = spektral.utils.laplacian(matrix_adj)
        # y, v = np.linalg.eig(y)
        return y


# ******************************** created feature none, adjacency matrix , and label**********************#

# ******************************** Visualization Matrix adjacency(A) and  Feature matrix(X) ****************#
def show_data(maf, mad, mna):
    sns.set_theme(style="ticks")
    fig = plt.figure(figsize=(2, 3))
    ax = fig.add_subplot(131)
    ax_ = fig.add_subplot(132)
    ax_1 = fig.add_subplot(133)
    im = ax.imshow(maf, interpolation='nearest')
    im_ = ax_.imshow(mad, interpolation='nearest')
    im_1 = ax_1.imshow(mna, interpolation='nearest')
    cbar = ax.figure.colorbar(im, ax=ax, shrink=0.33)
    cbar_ = ax_.figure.colorbar(im_, ax=ax_, shrink=0.33)
    cbar_1 = ax_.figure.colorbar(im_1, ax=ax_1, shrink=0.33)
    plt.setp(ax.get_xticklabels(),
             rotation=45,
             ha="right",
             rotation_mode="anchor")
    plt.setp(ax_.get_xticklabels(),
             rotation=45,
             ha="right",
             rotation_mode="anchor")
    plt.setp(ax_1.get_xticklabels(),
             rotation=45,
             ha="right",
             rotation_mode="anchor")

    ax.set_title(" X", size=10)
    ax.set_xlabel('N')
    ax.set_ylabel('F')
    ax_.set_title("A", size=10)
    ax_.set_xlabel('N')
    ax_.set_ylabel('N')
    ax_1.set_title("A'", size=10)
    ax_1.set_xlabel('N')
    ax_1.set_ylabel('N')
    #fig.tight_layout()
    # plt.savefig("Input2.png", format='png', dpi=75)
    plt.savefig("Output_3.png", format='png', dpi=65)
    plt.tight_layout()
    plt.show()

def recon_data(gp):
    sns.set_theme(style="ticks")
    fig = plt.figure(figsize=(2, 2))
    ax_ = fig.add_subplot()
    im_1 = ax_.imshow(gp, interpolation='gaussian')
    cbar_1 = ax_.figure.colorbar(im_1, ax=ax_, shrink=0.39)
    plt.setp(ax_.get_xticklabels(),
             rotation=45,
             ha="right",
             rotation_mode="anchor")

    ax_.set_title("Ground_point", size=10)
    ax_.set_xlabel('N')
    ax_.set_ylabel('F')
    fig.tight_layout()
    plt.savefig("GP_01.png", format='png', dpi=75)
    plt.tight_layout()
    plt.show()
