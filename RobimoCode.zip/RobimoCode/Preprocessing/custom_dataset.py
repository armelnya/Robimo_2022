import glob
import os
import sys
import numpy as np
import scipy.sparse as sp
import spektral.utils
from networkx import Graph
from spektral.data import Dataset, Graph, DisjointLoader, BatchLoader, Loader
from Preprocessing import input_data as Inp
import tensorflow as tf
from sklearn.decomposition import PCA
from spektral.layers import GCNConv, EdgeConv
from spektral.utils.sparse import sp_matrix_to_sp_tensor
from Utils.utils import mask_test_edges

# os.environ['TF_CPP_MIN_LOG_LEVEL'] = "2"
os.environ['CUDA_VISIBLE_DEVICES'] = "0"
physical_devices = tf.config.list_physical_devices("GPU")
if len(physical_devices) > 0:
    tf.config.experimental.set_memory_growth(physical_devices[0], True)

# ******************************** created Customer dataset *********************
Outputdirectory = "/home/lorraineshunie/RobimoCode/MyDataset/"
#Outputdirectory = "/home/ls/RobimoCode/MyDataset"
path_data = "/home/lorraineshunie/Downloads/Lichtenberg_bearbeitet.xyz"
#path_data = "/home/ls/Downloads/Lichtenberg_bearbeitet.xyz"


class custom_Dataset(Dataset):
    """
       created customer  dataset.
    """

    def __init__(self, p, num_row, knn, **kwargs):
        self.p = p
        self.num_row = num_row
        self.knn = knn
        super(custom_Dataset, self).__init__(**kwargs)

    def download(self):
        Prepro = Inp.Preprocess(self.p, self.num_row, self.knn)  # read data
        data = Prepro.Normalize_data()
        len_data = len(data)
        directory = "MyDataset"
        parent_dir = "/home/lorraineshunie/RobimoCode/"
        #parent_dir = "/home/ls/RobimoCode/"
        path = os.path.join(parent_dir, directory)
        try:
            # shutil.rmtree(path) # delete contain directory
            os.makedirs(path)
        except FileExistsError:
            pass
        # Write the data to file
        for i in range(self.num_row):  # Need to replace here with the length original data
            Prepro_2 = Inp.Preprocess_2(self.p, self.num_row, self.knn)
            MAD, MAL, ME = Prepro_2.adj_matrix()
            MAF = Prepro_2.matrix_feature()
            # eig_val, eig_vec = spektral.utils.laplacian(MAD)
            eig_val = Prepro_2.y_label()
            # Node features (Pca method)
            x = MAF
            # Adjacency matrix
            a = MAD
            # Edge features
            # e = ME
            # Labels
            y = eig_val
            filename = os.path.join(path, f'graph_{i}')
            np.savez(filename, x=x, a=a, y=y)

    def read(self):
        output = []
        output_file = os.path.join(Outputdirectory)
        for i in range(self.num_row):
            data = np.load(os.path.join(output_file, f'graph_{i}.npz'))
            output.append(Graph(x=data['x'], a=data['a'], y=data['y']))
        return output


graph_orig = custom_Dataset(path_data, 1, knn=4)
graph = graph_orig[0]
X = graph.x
A = graph.a
# Inp.show_data(X, A)
# print("graph:", graph_orig[0])
# print('A:', A)
# print('X:', X)
A_label = graph.a + sp.eye(graph.a.shape[0], dtype=np.float64)
A_label = A_label.reshape([-1])
#print('A_label:', A_label)
# A_label = np.squeeze(np.array(A_label)).reshape([-1])
#print('A_label:', A_label)
#print('A_label:', A_label.shape)
# Remove edges randomly from training set and put them in the validation/test sets
adj_train, _, val_edges, val_edges_false, test_edges, test_edges_false = mask_test_edges(graph.a)
# print("val_edge_false:", val_edges_false)
# print("test_edge_false:", test_edges)
# Normalize the adj matrix and convert it to sparse tensor
# A = GCNConv.preprocess(adj_train)
#A = sp_matrix_to_sp_tensor(A)
#X = sp_matrix_to_sp_tensor(X)
#print('A:', A)
#print('X:', X)
# Compute the class weights (necessary due to imbalanceness in the number of non-zero edges)
pos_weight = float(adj_train.shape[0] * adj_train.shape[0] - adj_train.sum()) / adj_train.sum()
# X, A,

# print('Y:', Y)
# print(graph_orig[0].n_node_features)
# X, A, E = sp.csr_matrix(X), sp.csr_matrix(A), sp.csr_matrix(Y)
# print('N:', graph_orig.n_nodes)
# print('F:', graph_orig.n_node_features)
