# !/usr/bin/python
# _*_/coding: utf-8 _*_
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import os
import sys
import numpy as np
import tensorflow as tf
import Preprocessing.input_data as Inp
import Preprocessing.custom_dataset as cud
import Model_GNN.model as md
import TrainTest.training as tr
# Fixing random state for reproducibility
np.random.seed(1234)
os.environ['TF_CPP_MIN_LOG_LEVEL'] = "2"
os.environ['CUDA_VISIBLE_DEVICES'] = "0"
physical_devices = tf.config.list_physical_devices("GPU")
if len(physical_devices) > 0:
    tf.config.experimental.set_memory_growth(physical_devices[0], True)


# ****************** Read your customer raw data xyz format **********************************#

path_data = "/home/ls/Downloads/Lichtenberg_bearbeitet.xyz"
Output_directory = "/home/ls/RobimoCode/MyDataset/"


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')
    print('Input_data_started:', Inp)
    print('Custom data:', cud.graph_orig)
    print('build_model:', md.model)
    print('training starter:', tr)


if __name__ == '__main__':
    print_hi('PyCharm')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
