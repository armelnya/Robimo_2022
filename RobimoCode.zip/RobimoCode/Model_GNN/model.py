from Preprocessing import custom_dataset as cd
import tensorflow as tf
from tensorflow.keras.layers import Dropout, Input
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.regularizers import l2
from spektral.layers import GCNConv

physical_devices = tf.config.list_physical_devices("GPU")
if len(physical_devices) > 0:
    tf.config.experimental.set_memory_growth(physical_devices[0], True)

# Parameters
hidden_dim1, hidden_dim2 = 32, 16  # Units in the GCN layers
dropout = 0.0  # Dropout rate
l2_reg = 0e-5  # L2 regularization rate
learning_rate = 1e-2  # Learning rate
epochs = 10000  # Max number of training epochs
val_epochs = 10  # After how many epochs should check the validation set
# N = cd.dataset_orig[0].n_nodes  # Number of nodes in the graph

N = cd.graph_orig.n_nodes
print("Number of Nodes in the Graph:", N)
F = cd.graph_orig.n_node_features  # Original size of node
# F = cd.graph_orig.n_node_features
print("Features Nodes", F)


def GNN(n, f):  # Graph auto-encoder
    x_in = Input(shape=(f,))
    a_in = Input((n,), sparse=True)
    gc_1 = GCNConv(
        hidden_dim1,
        activation="tanh",
        kernel_regularizer=l2(l2_reg),
    )([x_in, a_in])
    gc_1 = Dropout(dropout)(gc_1)
    gc_1 = GCNConv(
        hidden_dim1,
        activation="tanh",
        kernel_regularizer=l2(l2_reg),
    )([gc_1, a_in])
    gc_2 = Dropout(dropout)(gc_1)
    z = GCNConv(
        hidden_dim2,
        activation="tanh",
        kernel_regularizer=l2(l2_reg),
    )([gc_2, a_in])
    out = tf.matmul(z, tf.transpose(z))
    # This is not used for training, and we make it deterministic
    A_rec = tf.keras.layers.Activation('swish')(out)
    out = tf.reshape(out, [-1])
    model = Model(inputs=[x_in, a_in], outputs=[out, A_rec, z], name='GCN')
    return model


model = GNN(N, F)
opt = Adam(learning_rate=learning_rate)
# model.compile(optimizer=opt, loss='binary_crossentropy', metrics=['accuracy'])
# model.summary()
